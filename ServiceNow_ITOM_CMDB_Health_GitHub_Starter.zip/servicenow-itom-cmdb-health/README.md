# ServiceNow ITOM Automation – CMDB Health & Service Impact Management

Starter code for a **PDI-compatible CMDB health-to-incident automation simulation**. Designed to accompany an architecture document describing logistics workloads, Azure monitoring, CMDB context, and ITSM operations.

## What is actually implemented

- JavaScript test-data seeding for CMDB CIs.
- After-update Business Rule to create incidents when a CI transitions to `unhealthy`.
- Basic duplicate-incident detection by CI and active state.
- Impact / urgency field setting (priority normally calculated by instance rules).
- Copy of the CI's support group when populated.
- Verification and CI relationship inspection scripts.

This package **does not implement licensed ITOM Discovery, Service Mapping, AI/ML, Azure Monitor ingestion, or a production service-impact engine**. Impact text is rule-based and requires technician confirmation. The sample Azure payload is documentation-only.

## Requirements

- ServiceNow PDI or other non-production instance with CMDB, Incident Management, Business Rules, and Scripts - Background permissions.
- Avoid uploading credentials, instance secrets, real customer data, or tokens to GitHub.
- For native Discovery, Service Mapping, and Event Management use appropriately entitled ServiceNow capabilities.

## Installation

1. Open `cmdb_ci` dictionary and create a **Choice** field, column name `u_ai_health_status` (not `ai_health_status`). Add choices with exact internal values:
   - Label `Healthy`, value `healthy`
   - Label `Warning`, value `warning`
   - Label `Unhealthy`, value `unhealthy`
2. Optional: populate `support_group` on your sample CIs by assigning existing assignment groups in your instance. The seed script only records a suggested domain; it does not create groups.
3. Under **System Definition > Business Rules**, create a Business Rule named `Auto Incident on CI Health Degradation`:
   - Table: Configuration Item `[cmdb_ci]`
   - Advanced: checked; When: `after`
   - Update: checked; Insert: unchecked
   - Condition: `current.u_ai_health_status.changesTo('unhealthy')`
   - Script: paste `scripts/02_business_rule_on_unhealthy.js` (the `executeRule` function, not the comment header).
4. Run `scripts/01_seed_configuration_items.js` under **System Definition > Scripts - Background**.
5. Run `scripts/03_trigger_health_change.js` under Scripts - Background.
6. Open **Incident > All** and look for a short description beginning `[ITOM Health]`.
7. Run `scripts/04_verify_incidents.js` to print incident results.
8. Optional: run `scripts/05_ci_relationship_inspector.js` to inspect any previously configured CI relationships.

> Use either this Business Rule **or** a Flow Designer Create Record action for the same transition, not both; otherwise duplicate incident records may occur.

## Optional no-code Flow Designer alternative

Configure an update-triggered flow on `cmdb_ci` for a transition of `u_ai_health_status` to `unhealthy`. Check for an existing active health incident linked to the CI before creating a record. Set `cmdb_ci`, `short_description`, `description`, `impact`, `urgency`, and optional `assignment_group`. Note: exact flow controls and actions vary by release and entitlement.

## Repository structure

```text
scripts/
  01_seed_configuration_items.js
  02_business_rule_on_unhealthy.js
  03_trigger_health_change.js
  04_verify_incidents.js
  05_ci_relationship_inspector.js
samples/ci_health_event.json
tests/ACCEPTANCE_TESTS.md
docs/ARCHITECTURE.md
```

## Demonstration story

An Azure SQL-like CI named `AZ-DB-PROD-01` changes from Healthy to Unhealthy. ServiceNow reads the CI context, checks for an existing active health incident, and creates an incident for triage. Database Support can be assigned if the CI has a valid `support_group` reference. A technician confirms whether Shipment Tracking is impacted and documents the actual root cause.

## Production enhancements

- Azure Monitor integration via authenticated API, Logic Apps, or supported ITOM Event Management.
- IRE/reconciliation and discovered CI population with native Discovery or Service Graph Connectors.
- Native Service Mapping / mapped application services, rather than only CMDB relationships.
- Idempotency keys, correlation IDs, incident lifecycle recovery, performance thresholds, and alert suppression.
- SLA definitions, Major Incident workflow, reporting, and measured SLOs.
- Automated Test Framework coverage and deployment/update-set strategy.

## Portfolio integrity

Label this repository as a **lab simulation / reference implementation**, not proof of production Discovery, live AI inference, or fully automated root-cause analysis. Screenshots generated for documentation should be labeled illustrative unless taken from a real instance.
