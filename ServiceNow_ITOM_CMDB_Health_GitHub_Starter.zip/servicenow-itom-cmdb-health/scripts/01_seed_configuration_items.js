/**
 * Run: System Definition > Scripts - Background, in a NON-PRODUCTION instance.
 * Creates/updates three sample CIs in the base cmdb_ci class.
 * Run the custom field setup first (README).
 */
(function () {
    var examples = [
        { name: 'AZ-DB-PROD-01', description: 'Azure SQL-like CI used for project simulation', supportGroup: 'Database Support' },
        { name: 'VOYAGE-API-PRD', description: 'Integration application service CI used for project simulation', supportGroup: 'Application Support' },
        { name: 'WMS-GATEWAY-02', description: 'Warehouse gateway CI used for project simulation', supportGroup: 'Network Support' }
    ];
    var requiredField = 'u_ai_health_status';
    var check = new GlideRecord('cmdb_ci');
    if (!check.isValidField(requiredField)) {
        gs.error('Missing custom field cmdb_ci.' + requiredField + '. Create it before running this script.');
        return;
    }
    for (var i = 0; i < examples.length; i++) {
        var item = examples[i];
        var ci = new GlideRecord('cmdb_ci');
        ci.addQuery('name', item.name);
        ci.setLimit(1);
        ci.query();
        var exists = ci.next();
        if (!exists) {
            ci.initialize();
            ci.setValue('name', item.name);
        }
        ci.setValue('short_description', item.description);
        ci.setValue(requiredField, 'healthy');
        var id = exists ? (ci.update(), ci.getUniqueValue()) : ci.insert();
        gs.info('CI ' + item.name + ' | sys_id=' + id + ' | support domain=' + item.supportGroup);
    }
})();
