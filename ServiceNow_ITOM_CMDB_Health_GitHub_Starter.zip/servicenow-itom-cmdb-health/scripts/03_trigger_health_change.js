/** Run in Scripts - Background, non-production PDI. */
(function () {
    var ciName = 'AZ-DB-PROD-01';
    var ci = new GlideRecord('cmdb_ci');
    ci.addQuery('name', ciName);
    ci.setLimit(1);
    ci.query();
    if (!ci.next()) { gs.error('CI not found: ' + ciName); return; }
    if (!ci.isValidField('u_ai_health_status')) { gs.error('Missing u_ai_health_status'); return; }
    // Two separate updates ensure the changesTo('unhealthy') Business Rule can fire.
    ci.setValue('u_ai_health_status', 'healthy');
    ci.update();
    ci.get(ci.getUniqueValue());
    ci.setValue('u_ai_health_status', 'unhealthy');
    ci.update();
    gs.info('Health updated: ' + ciName + ' -> unhealthy');
})();
