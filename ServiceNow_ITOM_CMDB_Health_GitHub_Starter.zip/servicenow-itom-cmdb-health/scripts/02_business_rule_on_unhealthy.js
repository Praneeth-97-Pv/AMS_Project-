/**
 * Business Rule: Auto Incident on CI Health Degradation
 * Table: Configuration Item [cmdb_ci]
 * When: after, Update checked; Insert unchecked; Advanced checked
 * Condition (recommended in condition field): current.u_ai_health_status.changesTo('unhealthy')
 * Paste the FUNCTION BELOW into the Script field.
 * Use this OR Flow Designer's incident-creation flow, NOT BOTH.
 *
 * Scope: PDI / non-production training lab. Do not label this native ITOM Event Management.
 */
(function executeRule(current, previous /* null when async */) {
    var healthField = 'u_ai_health_status';
    if (!current.isValidField(healthField) || current.getValue(healthField) !== 'unhealthy') {
        return;
    }
    // Additional safeguard when the BR condition has not been configured.
    if (previous && previous.getValue(healthField) === 'unhealthy') {
        return;
    }

    // Avoid repeated incidents for the same CI while an existing incident is active.
    // This is a basic active-incident check, not a concurrency-safe deduplication lock.
    var existing = new GlideRecord('incident');
    existing.addQuery('cmdb_ci', current.getUniqueValue());
    existing.addQuery('active', true);
    existing.addQuery('short_description', 'STARTSWITH', '[ITOM Health]');
    existing.setLimit(1);
    existing.query();
    if (existing.next()) {
        gs.info('Existing active health incident: ' + existing.getValue('number'));
        return;
    }

    var ciName = current.getDisplayValue('name') || current.getUniqueValue();
    var incident = new GlideRecord('incident');
    incident.initialize();
    incident.setValue('short_description', '[ITOM Health] Unhealthy CI: ' + ciName);
    incident.setValue('description',
        'Automated CMDB health alert (simulation).\n' +
        'Configuration Item: ' + ciName + '\n' +
        'CI sys_id: ' + current.getUniqueValue() + '\n' +
        'Health: Unhealthy\n' +
        'Potential impact: Review linked application/business services and validate the scope of degradation.\n' +
        'Next steps: Verify CI availability, collect logs, and coordinate with the CI owner.\n' +
        'Note: This is rule-based text, not AI inference or confirmed root cause.');
    incident.setValue('cmdb_ci', current.getUniqueValue());

    // Demonstration only; priority normally follows instance Impact × Urgency rules.
    incident.setValue('impact', '2');
    incident.setValue('urgency', '2');

    // Route by a configurable CI support_group, if populated and valid.
    if (current.isValidField('support_group') && !current.support_group.nil()) {
        incident.setValue('assignment_group', current.getValue('support_group'));
    }
    incident.setValue('work_notes', 'Opened automatically when CI health transitioned to Unhealthy. Confirm service impact during triage.');
    var newId = incident.insert();
    if (!newId) {
        gs.error('Unable to create incident for CI: ' + ciName);
    } else {
        gs.info('Created incident ' + incident.getValue('number') + ' for CI: ' + ciName);
    }
})(current, previous);
