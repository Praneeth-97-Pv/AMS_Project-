/** Optional: examine existing relationships; does NOT perform native Service Mapping. */
(function () {
    var ci = new GlideRecord('cmdb_ci');
    ci.addQuery('name', 'AZ-DB-PROD-01');
    ci.setLimit(1);
    ci.query();
    if (!ci.next()) { gs.error('CI not found'); return; }
    var rel = new GlideRecord('cmdb_rel_ci');
    var query = rel.addQuery('parent', ci.getUniqueValue());
    query.addOrCondition('child', ci.getUniqueValue());
    rel.query();
    var count = 0;
    while (rel.next()) {
        gs.info(rel.getDisplayValue('parent') + ' --[' + rel.getDisplayValue('type') + ']--> ' + rel.getDisplayValue('child'));
        count++;
    }
    gs.info('Found ' + count + ' relationships for ' + ci.getDisplayValue('name'));
})();
