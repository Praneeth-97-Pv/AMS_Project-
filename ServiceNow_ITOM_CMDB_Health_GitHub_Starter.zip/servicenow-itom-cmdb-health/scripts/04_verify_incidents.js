/** Run in Scripts - Background after triggering a CI. */
(function () {
    var inc = new GlideRecord('incident');
    inc.addQuery('short_description', 'STARTSWITH', '[ITOM Health]');
    inc.orderByDesc('sys_created_on');
    inc.setLimit(20);
    inc.query();
    var count = 0;
    while (inc.next()) {
        count++;
        gs.info('Incident=' + inc.getValue('number') +
            ' | CI=' + inc.getDisplayValue('cmdb_ci') +
            ' | Impact=' + inc.getValue('impact') +
            ' | Urgency=' + inc.getValue('urgency') +
            ' | Group=' + inc.getDisplayValue('assignment_group') +
            ' | Active=' + inc.getValue('active'));
    }
    gs.info('Displayed ' + count + ' ITOM health incidents.');
})();
