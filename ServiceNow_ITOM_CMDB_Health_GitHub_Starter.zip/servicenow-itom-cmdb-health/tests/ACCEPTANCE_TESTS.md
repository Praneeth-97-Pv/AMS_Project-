# Acceptance tests (non-production PDI)

1. **Healthy -> Unhealthy:** Script `03_trigger_health_change.js` leads to one new incident linked to `AZ-DB-PROD-01`.
2. **Duplicate event:** Run the trigger a second time while the first incident remains active; no additional health incident should be created for the same CI.
3. **CI reference:** Incident `cmdb_ci` references the expected CI sys_id.
4. **Priority values:** Impact=2 and Urgency=2; calculated priority depends on the configured impact/urgency matrix.
5. **Assignment:** If CI `support_group` is set, it is copied; otherwise assignment may remain empty for manual routing.
6. **Warning state:** Changing to `warning` should not create an incident.
7. **Missing CI:** Background trigger logs an error and creates no new record.
8. **Active incident lifecycle:** Close the first incident, then trigger a new healthy-to-unhealthy transition; a new incident may be created.
9. **Relationship visibility:** Run inspector to list `cmdb_rel_ci` relationships if any exist.

**Caveat:** basic duplicate check is not atomic. Concurrent events can race. Production design needs a correlation key and idempotent ingestion controls.
